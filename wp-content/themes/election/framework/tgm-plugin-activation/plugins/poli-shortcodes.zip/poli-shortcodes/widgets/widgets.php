<?php

require_once( plugin_dir_path( __FILE__ ) .'advertise-widget.php' );
require_once( plugin_dir_path( __FILE__ ) .'category-widget.php' );
require_once( plugin_dir_path( __FILE__ ) .'contact-info-widget.php' );
require_once( plugin_dir_path( __FILE__ ) .'recent-posts-widget.php' );
require_once( plugin_dir_path( __FILE__ ) .'testimonials-widget.php' );
require_once( plugin_dir_path( __FILE__ ) .'recent-work-widget.php' );
require_once( plugin_dir_path( __FILE__ ) .'video-widget.php' );
require_once( plugin_dir_path( __FILE__ ) .'offer-widget.php' );
require_once( plugin_dir_path( __FILE__ ) .'aboutme-widget.php' );
require_once( plugin_dir_path( __FILE__ ) .'upcoming-events-widget.php' );
